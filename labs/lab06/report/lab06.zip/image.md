---
## Front matter
title: "Шаблон отчёта по лабораторной работе"
subtitle: "архитектура компьютерa"
author: "мохамед Муса"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---
# Цель работы

- Цель этой работы - углубиться в использование assembly и научиться выражать различные уравнения с помощью assemply.

# Выполнение лабораторной работы
- Сначала я создал файл lab6-1.asm, скопировал код из pdf и запустил его : 
![lab1](image/lab1.png){#fig:001 width=70%}

- И я внес необходимые изменения из pdf-файл в lab6-1.asm и запустил его снова : 
![lab1](image/edited_lab1.png){#fig:001 width=70%}

- Я также запустил файл lab6-2 и отредактировал его в соответствии с инструкцией в формате pdf :
![lab2](image/lab2.png){#fig:001 width=70%}
![lab2](image/edited_lab2.png){#fig:001 width=70%}

- В-третьих, я создал файл lab6-3.asm и использую его, чтобы научиться писать уравнения в asm : 
![lab3](image/lab3.png){#fig:001 width=70%}

- После этого я использовал код variant.asm, чтобы продемонстрировать, какая задача является моей :
![lab1](image/variant.png){#fig:001 width=70%}

- Найдя свою задачу, я написал код в соответствии с заданным выражением 5(x-1)^2 : 
![lab1](image/solve_variant.png){#fig:001 width=70%}
![lab1](image/x2.png){#fig:001 width=70%}
![lab1](image/code_work.png){#fig:001 width=70%}

# Отчет по выполнению лабораторной работы
1. Какие строки листинга 6.4 отвечают за вывод на экран сообщения ‘Ваш вариант:’?
 - **mov edx, msg1**
 - **call sprint**
2. Для чего используются следующие инструкции?
 - **mov ecx, x** — загрузка адреса буфера для ввода.
 - **mov edx, 80** — установка максимального размера ввода. call sread — вызов      функции для чтения строки.
3. Для чего используется инструкция **call atoi**?
 - Преобразование строки в целое число.
4. Какие строки листинга 6.4 отвечают за вычисления варианта?
 - **mov eax, variant mov ebx, 17**
 - **div ebx**
5. В какой регистр записывается остаток от деления при выполнении инструкции div ebx?
 - **В регистр edx.**
6. Для чего используется инструкция inc edx?
 - Увеличение значения в регистре **edx** на 1.
7. Какие строки листинга 6.4 отвечают за вывод на экран результата вычислений?
 - **mov eax**, **edx**
 - **call sprint_int**
# Выводы
В конце концов, мы научились писать выражения с помощью ассемблерного кода.

